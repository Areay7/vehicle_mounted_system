#include "weathertool.h"

QMap<QString, QString> WeatherTool::mCityMap = {};
