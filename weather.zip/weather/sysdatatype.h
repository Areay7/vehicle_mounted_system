#ifndef SYSDATATYPE_H
#define SYSDATATYPE_H

enum devSwitchStatus
{
    OFF,
    ON
};

enum AcMode
{
    ACAUTO,
    ACCOLD,
    ACHOT,
    ACDEMIST
};

#endif // SYSDATATYPE_H
